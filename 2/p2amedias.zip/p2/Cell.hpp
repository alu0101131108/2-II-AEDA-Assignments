class Board;
class Cell
{
  private:
  int x, y, state;

  public:
    Cell(int i = 0, int j = 0, int init_state = 0): x(i), y(j), state(init_state)
    {}

    int getState() const;
    int setState(int new_state);
    int updateState();
    int countNearCells(const Board & main_board);
    void SetXY(int i = 0, int j = 0);
    void Move(int i_desp = 0, int j_desp = 0);
    int getX();
    int getY();
};












// f12gggggggggggggggggg1222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222teeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee32gggggggggjrffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
